---
name: route-message
description: Send a message from one agent (or the user) to another agent's inbox
---

# Route Message Skill

Delivers a message to a specific agent's inbox for processing on its next run.

## Input required

1. **From** — sender name (user, or an agent name)
2. **To** — target agent name (must exist in REGISTRY.md)
3. **Message** — the content to deliver
4. **Priority** — normal / urgent

## Steps

1. Validate target agent exists in REGISTRY.md.
2. Append to ~/agents/{{target-agent}}/INBOX.md:

```
---
From: {{from}}
Date: {{timestamp}}
Priority: {{priority}}

{{message}}
---
```

3. If priority is urgent, also append to ~/agents/inbox/ global inbox
   with a note: "URGENT for {{target-agent}}: {{short summary}}"
4. Confirm delivery to user.

## Notes

- Agents should check and clear their INBOX.md at the start of each run.
- The orchestrator checks the global inbox/ on every run for urgent items.
