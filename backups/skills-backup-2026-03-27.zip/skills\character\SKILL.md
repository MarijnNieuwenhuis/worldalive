---
name: character
description: Create, build, update, generate, and manage characters in the character system
---

# Character Skill

Unified skill for all character operations. All character behavior is governed by `~/agents/character-curator/SOUL.md` — always read it before starting any session.

## Directory Structure

```
~/worlds/
  {world-name}/
    world.md                  — setting, lore, rules, tone
    characters/
      manual/                 — human-crafted (approval: required)
        {name}/
      generated/              — AI-generated (approval: auto)
        {name}/
    events/                   — world events that affect characters
    stories/                  — ingested stories
```

A character's `STATUS.md` contains:
- `Type: manual` or `Type: generated`
- `Approval: required` or `Approval: auto`
- `World: {world-name}`

**Manual characters:** Every file change must be shown to the user and approved before writing. No silent updates.
**Generated characters:** Can be updated automatically without confirmation.

Always read `world.md` before starting a session — it provides setting context (accent, tone, era, geography) that informs character details.

---

## Sub-commands

### /character new

Start a new manual character from scratch via the questionnaire.

1. Ask for the character's name.
2. Create `~/worlds/{world-name}/characters/manual/{name}/` directory.
3. Copy all stub files from `~/agents/templates/character/` into it, replacing `{{CHARACTER_NAME}}` with the actual name and `[DATE]` with today's date.
4. Set `STATUS.md`: `Type: manual`, `Approval: required`, `Last questionnaire session: {date}`, `Stories ingested: 0`
5. Read `~/agents/character-curator/SOUL.md` and begin the questionnaire from `soul.md`.

---

### /character resume [name]

Resume the questionnaire for an existing manual character.

1. Read all files in `~/worlds/{world-name}/characters/manual/{name}/`.
2. Identify incomplete files and H2 sections (stub content only).
3. Report briefly: "Covered: soul, appearance, voice. Picking up at: personality."
4. Read `~/agents/character-curator/SOUL.md` and resume from the first incomplete file or section.
5. After the session, update `STATUS.md` — set "Last questionnaire session" to today's date and note what was covered.

---

### /character update [name]

Update a specific character based on changed requirements, new information, or user direction.

1. Ask what needs updating (or read the context if it's clear).
2. Read the character's current files.
3. If `Approval: required`: show all proposed changes to the user and get approval before dispatching.
4. Dispatch a subagent to apply the approved changes:
   - Subagent receives: character directory path, current file contents, exact changes to make
   - Subagent writes updates and reports what it changed
5. Note the update in `STATUS.md`.

---

### /character update-all

Propagate changes to all characters in parallel — used when character-curator SOUL.md adds new requirements, new file types, or new H2 sections, or when a story/world event affects the whole cast.

1. Read `~/agents/character-curator/SOUL.md` to understand current requirements.
2. Ask which world to update (or all worlds). Read all characters in that world's `characters/manual/` and `characters/generated/`.
3. For each character, identify what needs updating (gaps, new requirements, event impact).
4. **Manual characters first:** Collect all proposed changes across all manual characters, present them to the user grouped by character, and get approval before proceeding.
5. Once approved (or for generated characters without approval needed), dispatch one subagent per character in parallel:
   - Each subagent receives: character directory path, current file contents, exact changes to make
   - Each subagent applies changes and reports what it did
6. After all subagents complete, report: "Updated N characters. Changes: [summary per character]"

---

### /character generate [n]

Auto-generate N characters in parallel using multiple subagents.

**Input required:**
1. How many characters (n)
2. Optional brief for each or for all: genre, role, relationship to others, any constraints

**Steps:**
1. If no brief given, ask for one — even "diverse supporting cast for a noir story" is enough.
2. Dispatch N subagents in parallel, each generating one complete character:
   - Each subagent creates `~/worlds/{world-name}/characters/generated/{generated-name}/`
   - Copies templates, fills all 13 files based on the brief
   - Sets `STATUS.md`: `Type: generated`, `Approval: auto`
   - Writes a short summary of who they created
3. After all subagents complete, present a summary of all generated characters.
4. Ask the user: "Want to promote any of these to manual?" — promoted characters move to `manual/`, their STATUS.md updates to `Approval: required`.

**Naming generated characters:** Use descriptive kebab-case names (e.g., `the-bartender`, `rival-detective`) unless the brief specifies names.

---

### /character list

Show all characters and their status.

1. List all worlds in `~/worlds/`. For each world, read `STATUS.md` for every character in `characters/manual/` and `characters/generated/`.
2. Present a table:

```
Manual characters:
  jolene        — last session: 2026-03-24, stories: 0, files: 12/13 complete
  ...

Generated characters:
  (none yet)
```

3. Flag any character with incomplete files or unresolved contradictions.

---

## Notes

- The full session behavior (questionnaire flow, story ingestion, scenario generation, contradiction handling) lives in `~/agents/character-curator/SOUL.md`. This skill handles routing and setup — the SOUL.md handles everything else.
- When a story event or world event affects characters, use `/character update [name]` or `/character update-all` with the event as context.
- Never delete a character directory without explicit user confirmation, regardless of type.
