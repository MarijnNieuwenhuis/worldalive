---
name: update-agent
description: Update an existing agent's configuration, role, or preferences
---

# Update Agent Skill

Modifies an existing agent's configuration. Never touches MEMORY.md.

## Input required

Ask the user:
1. **Which agent** — name from REGISTRY.md
2. **What to change** — one or more of:
   - Role / responsibilities (updates SOUL.md)
   - Personality (updates SOUL.md)
   - Schedule (updates REGISTRY.md)
   - MCP tool access (updates PREFERENCES.md and MCP_REGISTRY.md)
   - Configuration / limits (updates PREFERENCES.md)

## Steps

1. Read current agent files to understand existing config.
2. Apply requested changes to the appropriate files.
3. Update REGISTRY.md if schedule or tools changed.
4. Update MCP_REGISTRY.md if tool permissions changed.
5. Add a note to the agent's MEMORY.md: "SYSTEM: Agent configuration updated on {{date}}. Changes: {{summary}}."
6. Confirm changes to user.

## Safety

- Always show the user what will change before applying.
- Never delete or overwrite MEMORY.md content.
- If removing MCP tool access, warn if the agent's core responsibilities depend on it.
