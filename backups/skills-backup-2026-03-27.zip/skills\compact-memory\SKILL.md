---
name: compact-memory
description: Compress and prune an agent's memory to prevent context overflow
---

# Compact Memory Skill

Prevents memory files from growing beyond useful size.

## When to run

- Automatically: when an agent's MEMORY.md exceeds 50KB (configurable in PREFERENCES.md)
- Manually: when user requests it
- Scheduled: as a weekly maintenance task for all agents

## Steps

1. Read the agent's MEMORY.md.
2. Identify entries in "Recent Activity" older than 14 days.
3. Summarize those entries into concise bullet points grouped by theme/topic.
4. Move summaries to the "Compacted History" section.
5. Remove the original detailed entries from "Recent Activity."
6. Add a compaction note: "SYSTEM: Memory compacted on {{date}}. {{N}} entries summarized."

## Rules

- Never discard information completely — always summarize before removing.
- Keep the most recent 14 days of detailed entries untouched.
- If Compacted History itself is growing large, summarize it further into key themes.
- Preserve any entry tagged with [IMPORTANT] or [PINNED] regardless of age.
