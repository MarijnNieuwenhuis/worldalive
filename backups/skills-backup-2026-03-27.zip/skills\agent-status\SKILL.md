---
name: agent-status
description: Get a quick overview of all agents and their health
---

# Agent Status Skill

Provides a human-readable summary of the entire system.

## Steps

1. Read ~/agents/STATUS.md for the global overview.
2. Read REGISTRY.md for the agent list.
3. For each agent, read its STATUS.md.
4. Present a summary:

```
System Overview (as of {{date}})

Agents: {{total}} registered, {{active}} active, {{errored}} with errors

{{For each agent:}}
[agent-name] — {{status}}
  Last run: {{timestamp}}
  Schedule: {{schedule}}
  Memory size: {{file size of MEMORY.md}}
  Notes: {{any alerts or recent errors}}
```

5. If any agents have 3+ consecutive errors, highlight them prominently.
6. If any agent's memory exceeds 50KB, suggest running compact-memory.
