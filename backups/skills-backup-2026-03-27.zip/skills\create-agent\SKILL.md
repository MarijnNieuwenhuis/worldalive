---
name: create-agent
description: Create a new agent in the multi-agent system
---

# Create Agent Skill

Creates a new agent by scaffolding its folder and registering it.

## Input required

Ask the user for:
1. **Agent name** — short, lowercase, kebab-case (e.g., "price-tracker")
2. **Role** — one sentence describing what this agent does
3. **Personality** — how it should behave (frugal, thorough, concise, etc.)
4. **Responsibilities** — bullet list of specific tasks
5. **Schedule** — how often it should run (hourly, daily:HH:MM, on-demand, every:Xh)
6. **MCP tools** — which tools from MCP_REGISTRY.md it needs access to

## Steps

1. Create folder: `~/agents/{{agent-name}}/`
2. Copy and fill templates:
   - SOUL.md from templates/SOUL.md.template
   - MEMORY.md from templates/MEMORY.md.template
   - PREFERENCES.md from templates/PREFERENCES.md.template
3. Create empty INBOX.md with header: `# {{agent-name}} — Inbox`
4. Create STATUS.md with: `# {{agent-name}} — Status\n\nLast run: never\nResult: pending`
5. Add entry to ~/agents/REGISTRY.md
6. Update MCP_REGISTRY.md agent permissions table
7. Confirm to user: "Agent '{{agent-name}}' created. It will be picked up on the next orchestrator run."

## Validation

- Ensure agent name is unique in REGISTRY.md
- Ensure requested MCP tools exist in MCP_REGISTRY.md
- Ensure folder doesn't already exist
