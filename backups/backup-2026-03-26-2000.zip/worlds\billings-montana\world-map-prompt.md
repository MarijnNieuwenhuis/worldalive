# World Map — Billings, Montana (2026)

Use this as context when generating scenes, character movement, or events in the world.

---

## Physical Setting

**City:** Billings, Montana — largest city in the state, population ~123,600.
**Position:** Yellowstone River valley. The river runs along the north edge of the city. To the south, sandstone Rimrocks rise 500–800 feet above the city floor — a defining visual on the skyline.
**Feel:** Grid city. Flat, open, big sky. Not scenic in an obvious way — you have to look for it. The kind of place where people drive hours just to shop here because there's nothing else nearby.

---

## Major Roads

| Road | Orientation | Notes |
|------|-------------|-------|
| **I-90** | East–West | The main interstate, bisects the city horizontally through the center |
| **27th Street** | North–South | Main arterial, runs from near the river south to the Rimrocks |
| **1st Ave N** | East–West | Runs through the northern quarter, connects Heights to Downtown |
| **Grand Ave** | East–West | Runs through the southern half, West End to Midtown |

Secondary streets run parallel and cross in a loose grid. Most are unnamed in daily conversation — people navigate by landmarks and neighborhoods, not street numbers.

---

## Neighborhoods

### The Heights (northeast)
Older residential area. Working-class, unpretentious. People who've been here their whole lives. Houses are small and maintained. Streets are quiet. The Heights Apartment complex and Heights Auto & Repair are anchors here. St. Vincent Hospital is on the edge of this neighborhood.

### Downtown (central)
The only neighborhood visibly changing. Breweries, galleries, small restaurants. Young professional energy that hasn't quite committed yet — it could flip back. Tuck's Books is here (just north of downtown core on 1st Ave N). The Rail Bar is a downtown fixture. The Downtown Apartment complex houses several characters.

### West End (west/southwest)
Suburban sprawl. Strip malls, chain restaurants, a hardware store or two. Gen X energy — stable, a little sleepy. Cole's Ranch is technically outside the city's west edge. The West End Residential Site is a newer development here. Petra Szabo's Landscape Architecture Office sits at the edge of West End toward Midtown.

### Midtown (southeast of center)
Small-town feel despite being central. Diners, the Midtown Outfitter Shop, the kind of block that doesn't change. Quieter than downtown. Travis Kimura works here.

---

## Named Locations

These are the specific places characters live, work, and spend time.

### Tuck's Books
**Type:** Independent bookstore
**Location:** Just north of downtown core, on 1st Ave N (map coords ~42, 28)
**Who:** Amber Tuck owns and runs it. Jolene Voss visits.
**Feel:** Small, curated, quiet during weekday mornings. Coffee smell. Tall shelves. Amber opens at 09:00. Often empty for the first hour or two. The kind of store that shouldn't survive but does, because people who care about it make sure it does.

### The Rail Bar
**Type:** Bar / gathering spot
**Location:** Downtown, south of 1st Ave N near I-90 (map coords ~47, 47)
**Who:** Evening social hub. Multiple characters end up here.
**Feel:** Low-lit, wood interior, not trendy. Railroad memorabilia. The bar where Billings people go when they want a drink without spectacle. Gets louder after 17:00.

### Downtown Coffee Shop
**Type:** Coffee shop / café
**Location:** Central downtown, just east of 27th St (map coords ~53, 42)
**Who:** Eli Marsh works here.
**Feel:** Morning rush, then quiet. Eli ties on his apron the same way every morning. The kind of place regulars treat as an extension of their kitchen. Eli finds it comforting and quietly defeating in equal measure.

### Downtown Apartment
**Type:** Residential — apartment complex
**Location:** Central downtown, near the Rail Bar (map coords ~44, 44)
**Who:** Cassidy Lane lives here.
**Feel:** Mid-range. Unremarkable hallways. Decent location, walkable to most downtown spots.

### Home (residential cluster)
**Type:** Residential — generic neighborhood homes
**Location:** East of 27th St, north of I-90 (map coords ~58, 40) — near Senior High
**Who:** Jolene Voss, Marcus Delaney, Nora Whitfield, and others at various times.
**Feel:** Typical Billings residential block. Single-story houses, yards, quiet streets. Morning coffee at the kitchen table. The sound of trucks on the road outside.

### Billings Senior High
**Type:** High school
**Location:** East of 27th St, north of I-90 (map coords ~60, 35)
**Who:** Ryan Ostrowski teaches here.
**Feel:** Standard public high school. Gymnasium, administration wing, parking lot. Ryan has been here long enough that the routine is both anchor and weight.

### The Heights Apartment
**Type:** Residential — apartment complex
**Location:** The Heights neighborhood, northeast (map coords ~70, 28)
**Who:** Dani Rowe lives here.
**Feel:** Older building. Good bones. Views toward the south. The Heights has a different feel than downtown — quieter, more established.

### Heights Auto & Repair
**Type:** Auto repair shop
**Location:** The Heights, just below 1st Ave N (map coords ~72, 30)
**Who:** Dani Rowe works here.
**Feel:** Concrete floor, lifts, oil smell. Radio on. Work is physical and honest. Dani knows most of the regulars.

### St. Vincent Hospital
**Type:** Regional hospital (Catholic health system)
**Location:** The Heights, near the apartment complex (map coords ~68, 24)
**Who:** Background — not a primary character workplace, but a major city landmark.
**Feel:** The regional medical hub. People drive hours to get here. Large, busy, understaffed relative to the regional need. Mental health services are stretched thin.

### Landscape Architecture Office (Midtown)
**Type:** Small professional office
**Location:** Edge of West End/Midtown (map coords ~35, 58)
**Who:** Petra Szabo works here.
**Feel:** Small office, drafting tables, plans rolled in tubes. Petra is often the only one there. Her work shapes the city slowly, invisibly.

### Midtown Outfitter Shop
**Type:** Outdoor/sporting goods retail
**Location:** Midtown, south of I-90 (map coords ~56, 56)
**Who:** Travis Kimura works here.
**Feel:** Gear, maps, hiking boots, hunting licenses. Regular customers who know what they want. Travis likes the quiet rhythms of it.

### West End Residential Site
**Type:** Residential development / construction site or newer housing
**Location:** West End (map coords ~25, 55)
**Who:** Background location — area where Marcus Delaney or others may be seen.
**Feel:** Newer construction. Sod lawns that haven't quite taken. The suburban edge where the city gives way to open land.

### Cole's Ranch
**Type:** Working cattle ranch
**Location:** Southwest, outside the city proper (map coords ~20, 70)
**Who:** Cole Brandt lives and works here.
**Feel:** Fences, pasture, hay smell, early mornings. Cole is up before anyone else in the city. The ranch is outside the grid — a different pace entirely. There's fence line that needs repair, always.

### CHS Refinery
**Type:** Industrial — oil refinery
**Location:** Far southwest, industrial zone (map coords ~15, 75)
**Who:** Background — a major employer in the city, visible from most of the south side.
**Feel:** Tanks, pipes, flame stack. The refinery operates 24 hours. Shift workers. The smell reaches parts of the city on certain wind days. It's part of the skyline in a different way than the Rimrocks — industrial rather than natural.

---

## Ambient Landmarks (background texture)

| Landmark | Location | Notes |
|----------|----------|-------|
| **Pioneer Park** | East side, near I-90 (x:78, y:45) | Open parkland. Families on weekends. |
| **Rose Park** | Northwest, near 1st Ave N (x:22, y:28) | Small neighborhood park. |
| **BIL Airport** | Far east edge | Small regional airport. Flights to Denver, Seattle, Salt Lake. |
| **Yellowstone River** | North boundary | Flat and wide here. Not dramatic but always present. |
| **Rimrocks** | South boundary | 500–800 ft sandstone cliffs. Visible from most of the city. |

---

## Distance and Travel

- **Downtown to Heights:** ~10 min drive, walkable in 25–30 min
- **Downtown to West End:** ~10–15 min drive
- **Downtown to Cole's Ranch:** ~20–25 min drive
- **City to next major city:** 3–5+ hours in any direction
- Most characters get around by car. Walking is possible in the core but unusual for longer trips.

---

## What Isn't Here

Billings has no subway, no tram, minimal bus infrastructure. There's no "scene" in the way a major city has one — no neighborhood that feels like a destination. What exists is what's always existed: the refinery, the ranches, the hospital, the schools, the handful of bars where the same people show up. The energy-sector jobs. The railroad history.

The downtown arts scene (Tuck's Books, small galleries, a couple of breweries) is real but fragile. It survives on stubbornness.

---

## Prompt Usage Notes

When writing events or scenes in this world:
- **Characters travel by car** unless the scene specifically involves walking (e.g., downtown errands)
- **Morning (06:00–09:00):** Characters are at home, commuting, or just opening their workplace
- **Midday (12:00–14:00):** Lunch breaks, errands, unplanned encounters
- **Evening (17:00–20:00):** End of work, Rail Bar, home cooking, quiet
- **Night (20:00+):** Private — home, insomnia, the quiet of a city that goes to sleep early
- A **water main break, a school event, a ranch emergency** — these are the kinds of things that change a day here, not something dramatic
- The **Rimrocks** and the **river** are always in the background — use them for mood, not just geography
