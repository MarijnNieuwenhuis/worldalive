# Timeline — Billings, Montana

*Chronological record of every time step. Appended by world-clock after each tick.*

## Entry Format

```
## [Day name], [YYYY-MM-DD] at [HH:mm]
- [Character name] — [Location] ([activity or status])
- [Character name] — [Location] ([activity or status])
```

Example:
```
## Saturday, 2026-03-28 at 20:00
- Jolene — The Fieldhouse restaurant (dinner with Cassidy)
- Cassidy — The Fieldhouse restaurant (dinner with Jolene)
- Marcus — Billings Clinic ER (broken leg, being treated)
- Amber — home (evening, reading)
- Cole — Cole's ranch (done for the day)
- Dani — her apartment (after work)
- Eli — climbing gym (bouldering session)
- Nora — Billings Clinic (night shift)
- Petra — home (working at drafting table)
- Ryan — home (evening)
- Travis — Yellowstone River (evening fly fishing)
```

---

(No entries yet — timeline begins on first world-clock tick)
