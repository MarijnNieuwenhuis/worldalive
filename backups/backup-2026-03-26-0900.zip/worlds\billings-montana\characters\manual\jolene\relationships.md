# Jolene Voss — Relationships

*Key people. Each relationship is updated as stories are ingested.*

## Arleen *(deceased)*

**Who they are:** Jolene's closest friend. Same age, grew up together.

**How they met:** Childhood — they grew up side by side.

**Dynamic:** The one person Jolene was fully herself around. No performance, no walls. Arleen knew the version of Jolene that nobody else gets to see.

**History / tension:** Arleen died in a car accident. The loss is unresolved — something about it hasn't been fully faced or spoken. Jolene still wears the necklace Arleen gave her every day.

**Feels vs acts:** She doesn't talk about Arleen much. The grief is quiet and constant. The unresolved part sits underneath everything — it will surface in stories eventually.

<!-- More relationships to be added later -->
